import React from 'react';
import { Pressable, View } from 'react-native';
import { useTheme } from '../context/ThemeContext';
import { radius, space, TOUCH } from '../theme';
import { Label, Small } from './ui';

interface Props {
  label: string;
  mode: 'date' | 'time';
  /** 'YYYY-MM-DD' for dates, 'HH:mm' for times; empty when not set */
  value: string;
  onChange: (value: string) => void;
  /** lets the person remove an optional value */
  onClear?: () => void;
  placeholder?: string;
}

/** iPhone version: Safari's own date and time pickers, via a native <input>. */
export function DateTimeField({ label, mode, value, onChange, onClear }: Props) {
  const { palette } = useTheme();
  return (
    <View style={{ marginBottom: space.lg }}>
      <Label style={{ marginBottom: space.xs }}>{label}</Label>
      <input
        type={mode}
        aria-label={label}
        value={value}
        onChange={e => {
          const v = e.target.value;
          if (v) onChange(v);
        }}
        style={{
          minHeight: TOUCH,
          width: '100%',
          boxSizing: 'border-box',
          border: `1.5px solid ${palette.line}`,
          borderRadius: radius.md,
          backgroundColor: palette.surface,
          color: palette.ink,
          fontSize: 16,
          padding: `0 ${space.lg}px`,
          fontFamily: 'inherit',
        }}
      />
      {onClear && value ? (
        <Pressable accessibilityRole="button" onPress={onClear} style={{ paddingVertical: space.sm }}>
          <Small style={{ color: palette.primary, fontWeight: '700' }}>Remove {label.toLowerCase()}</Small>
        </Pressable>
      ) : null}
    </View>
  );
}
