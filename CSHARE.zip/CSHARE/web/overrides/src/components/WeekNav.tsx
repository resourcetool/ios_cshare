import React from 'react';
import { StyleSheet, View } from 'react-native';
import { formatWeekRange, parseDateKey, shiftWeek, toDateKey, weekIdFor } from '../utils/dates';
import { useTheme } from '../context/ThemeContext';
import { radius, space } from '../theme';
import { Button, Heading, Label, Small } from './ui';

/** `minWeekId`: pass the current week to stop navigation into the past (used for normal users).
 * iPhone version: "Go to a date" uses Safari's date picker instead of Android's dialog. */
export function WeekNav({ weekId, onChange, minWeekId }: { weekId: string; onChange: (id: string) => void; minWeekId?: string }) {
  const { palette } = useTheme();
  const thisWeek = weekIdFor(new Date());
  const label = weekId === thisWeek ? 'This week' : weekId === shiftWeek(thisWeek, 1) ? 'Next week' : weekId === shiftWeek(thisWeek, -1) ? 'Last week' : 'Week';
  const atFloor = !!minWeekId && weekId <= minWeekId;

  const pick = (v: string) => {
    if (!v) return;
    const target = weekIdFor(parseDateKey(v));
    onChange(minWeekId && target < minWeekId ? minWeekId : target);
  };

  return (
    <View style={[styles.wrap, { borderBottomColor: palette.line }]}>
      <Small>{label}</Small>
      <Heading>{formatWeekRange(weekId)}</Heading>
      <View style={styles.row}>
        <Button label="◀ Earlier" variant="secondary" onPress={() => onChange(shiftWeek(weekId, -1))} style={{ flex: 1 }} disabled={atFloor} />
        <Button label="Later ▶" variant="secondary" onPress={() => onChange(shiftWeek(weekId, 1))} style={{ flex: 1 }} />
      </View>
      <View style={styles.row}>
        <View style={{ flex: 1 }}>
          <Label style={{ marginBottom: space.xs }}>Go to a date</Label>
          <input
            type="date"
            aria-label="Go to a date"
            value={toDateKey(parseDateKey(weekId))}
            min={minWeekId}
            onChange={e => pick(e.target.value)}
            style={{ minHeight: 44, width: '100%', boxSizing: 'border-box', border: `1px solid ${palette.line}`, borderRadius: radius.md, backgroundColor: palette.surface, color: palette.ink, fontSize: 16, padding: `0 ${space.md}px`, fontFamily: 'inherit' }}
          />
        </View>
        {weekId !== thisWeek ? <Button label="This week" variant="ghost" onPress={() => onChange(thisWeek)} style={{ flex: 1, alignSelf: 'flex-end' }} /> : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { paddingBottom: space.md, borderBottomWidth: 1, marginBottom: space.sm },
  row: { flexDirection: 'row', gap: space.md, marginTop: space.sm },
});
